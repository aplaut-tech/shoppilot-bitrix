<?
$arModuleVersion = array(
	"VERSION" => "2.0.0",
	"VERSION_DATE" => "2013-11-18 10:00:00"
);
?>
