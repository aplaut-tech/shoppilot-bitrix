<?

$updater->CopyFiles("classes", "modules/shoppilot.reviews/classes");
$updater->CopyFiles("lang", "modules/shoppilot.reviews/lang");
$updater->CopyFiles("install", "modules/shoppilot.reviews/install");

?>